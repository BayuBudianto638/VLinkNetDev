﻿namespace MCF_FrontEnd.Models.Account
{
    public class LoginViewModel
    {
        public string User { get; set; }
        public string Password { get; set; }
    }
}
