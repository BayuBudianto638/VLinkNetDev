﻿using AutoMapper;

namespace MCF_FrontEnd.ConfigProfile
{
    public class ConfigurationProfile : Profile
    {
        public ConfigurationProfile() { }
    }
}
